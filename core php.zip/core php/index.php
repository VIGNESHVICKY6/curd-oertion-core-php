<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php  include('server.php'); ?>
<html>
<head>
	<title>CRUD: CReate, Update, Delete PHP MySQL</title>
        <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <table>
	<thead>
		<tr>
			<th>Name</th>
			<th>Address</th>
			<th colspan="2">Action</th>
		</tr>
	</thead>
        <tbody>
            <?php while($row= mysqli_fetch_array($results)){ ?>
            <tr>
                <td> <?php echo $row['name'];?></td>
                <td> <?php echo $row['address'];?></td>
                <td><a href="index.php?edit=<?php echo $row['id']; ?>" class="edit_btn" >Edit</a></td>
                <td> <a href="server.php?del=<?php echo $row['id']; ?>" class="del_btn">Delete</a></td>
            </tr>
            <?php }?>
            
        </tbody>
    </table>
	<form method="post" action="server.php" >
		<div class="input-group">
			<label>Name</label>
			<input type="text" name="name" value="">
		</div>
		<div class="input-group">
			<label>Address</label>
			<input type="text" name="address" value="">
		</div>
		<div class="input-group">
		<?php if ($update == true): ?>
	         <button class="btn" type="submit" name="update" style="background: #556B2F;" >update</button>
                <?php else: ?>
	        <button class="btn" type="submit" name="save" >Save</button>
                 <?php endif ?>
		</div>
	</form>
   
</body>
</html>